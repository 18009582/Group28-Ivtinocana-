﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class CAR_BOOKINGController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: CAR_BOOKING
        Function Index() As ActionResult
            Dim cAR_BOOKING = db.CAR_BOOKING.Include(Function(c) c.CAR).Include(Function(c) c.CAR_BOOKING_SLOTS).Include(Function(c) c.USER)
            Return View(cAR_BOOKING.ToList())
        End Function

        ' GET: CAR_BOOKING/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING As CAR_BOOKING = db.CAR_BOOKING.Find(id)
            If IsNothing(cAR_BOOKING) Then
                Return HttpNotFound()
            End If
            Return View(cAR_BOOKING)
        End Function

        ' GET: CAR_BOOKING/Create
        Function Create() As ActionResult
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG")
            ViewBag.CARBOOKINGSLOTID = New SelectList(db.CAR_BOOKING_SLOTS, "CARBOOKINGSLOTID", "CARBOOKINGSLOTID")
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME")
            Return View()
        End Function

        ' POST: CAR_BOOKING/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="CARBOOKING_ID,CAR_ID,CARBOOKINGSLOTID,USER_ID,STATUS,BOOKING_DATE,BOOKING_TIME")> ByVal cAR_BOOKING As CAR_BOOKING) As ActionResult
            If ModelState.IsValid Then
                db.CAR_BOOKING.Add(cAR_BOOKING)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", cAR_BOOKING.CAR_ID)
            ViewBag.CARBOOKINGSLOTID = New SelectList(db.CAR_BOOKING_SLOTS, "CARBOOKINGSLOTID", "CARBOOKINGSLOTID", cAR_BOOKING.CARBOOKINGSLOTID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR_BOOKING.USER_ID)
            Return View(cAR_BOOKING)
        End Function

        ' GET: CAR_BOOKING/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING As CAR_BOOKING = db.CAR_BOOKING.Find(id)
            If IsNothing(cAR_BOOKING) Then
                Return HttpNotFound()
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", cAR_BOOKING.CAR_ID)
            ViewBag.CARBOOKINGSLOTID = New SelectList(db.CAR_BOOKING_SLOTS, "CARBOOKINGSLOTID", "CARBOOKINGSLOTID", cAR_BOOKING.CARBOOKINGSLOTID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR_BOOKING.USER_ID)
            Return View(cAR_BOOKING)
        End Function

        ' POST: CAR_BOOKING/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="CARBOOKING_ID,CAR_ID,CARBOOKINGSLOTID,USER_ID,STATUS,BOOKING_DATE,BOOKING_TIME")> ByVal cAR_BOOKING As CAR_BOOKING) As ActionResult
            If ModelState.IsValid Then
                db.Entry(cAR_BOOKING).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", cAR_BOOKING.CAR_ID)
            ViewBag.CARBOOKINGSLOTID = New SelectList(db.CAR_BOOKING_SLOTS, "CARBOOKINGSLOTID", "CARBOOKINGSLOTID", cAR_BOOKING.CARBOOKINGSLOTID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR_BOOKING.USER_ID)
            Return View(cAR_BOOKING)
        End Function

        ' GET: CAR_BOOKING/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING As CAR_BOOKING = db.CAR_BOOKING.Find(id)
            If IsNothing(cAR_BOOKING) Then
                Return HttpNotFound()
            End If
            Return View(cAR_BOOKING)
        End Function

        ' POST: CAR_BOOKING/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim cAR_BOOKING As CAR_BOOKING = db.CAR_BOOKING.Find(id)
            db.CAR_BOOKING.Remove(cAR_BOOKING)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
