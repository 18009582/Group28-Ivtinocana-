﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class MAKEsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: MAKEs
        Function Index() As ActionResult
            Return View(db.MAKEs.ToList())
        End Function

        ' GET: MAKEs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mAKE As MAKE = db.MAKEs.Find(id)
            If IsNothing(mAKE) Then
                Return HttpNotFound()
            End If
            Return View(mAKE)
        End Function

        ' GET: MAKEs/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: MAKEs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="MAKE_ID,MAKE_NAME")> ByVal mAKE As MAKE) As ActionResult
            If ModelState.IsValid Then
                db.MAKEs.Add(mAKE)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(mAKE)
        End Function

        ' GET: MAKEs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mAKE As MAKE = db.MAKEs.Find(id)
            If IsNothing(mAKE) Then
                Return HttpNotFound()
            End If
            Return View(mAKE)
        End Function

        ' POST: MAKEs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="MAKE_ID,MAKE_NAME")> ByVal mAKE As MAKE) As ActionResult
            If ModelState.IsValid Then
                db.Entry(mAKE).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(mAKE)
        End Function

        ' GET: MAKEs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mAKE As MAKE = db.MAKEs.Find(id)
            If IsNothing(mAKE) Then
                Return HttpNotFound()
            End If
            Return View(mAKE)
        End Function

        ' POST: MAKEs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim mAKE As MAKE = db.MAKEs.Find(id)
            db.MAKEs.Remove(mAKE)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
