﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class OFFERsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: OFFERs
        Function Index() As ActionResult
            Dim oFFERS = db.OFFERS.Include(Function(o) o.CAR).Include(Function(o) o.OFFER_STATUS).Include(Function(o) o.OFFER_TYPE).Include(Function(o) o.USER)
            Return View(oFFERS.ToList())
        End Function

        ' GET: OFFERs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim oFFER As OFFER = db.OFFERS.Find(id)
            If IsNothing(oFFER) Then
                Return HttpNotFound()
            End If
            Return View(oFFER)
        End Function

        ' GET: OFFERs/Create
        Function Create() As ActionResult
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG")
            ViewBag.STATUS_ID = New SelectList(db.OFFER_STATUS, "STATUS_ID", "STATUS_NAME_")
            ViewBag.OFFERTYPE_ID = New SelectList(db.OFFER_TYPE, "OFFERTYPE_ID", "OFFERTYPE")
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME")
            Return View()
        End Function

        ' POST: OFFERs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="OFFER_ID,CAR_ID,STATUS_ID,OFFERTYPE_ID,USER_ID,AMOUNT")> ByVal oFFER As OFFER) As ActionResult
            If ModelState.IsValid Then
                db.OFFERS.Add(oFFER)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", oFFER.CAR_ID)
            ViewBag.STATUS_ID = New SelectList(db.OFFER_STATUS, "STATUS_ID", "STATUS_NAME_", oFFER.STATUS_ID)
            ViewBag.OFFERTYPE_ID = New SelectList(db.OFFER_TYPE, "OFFERTYPE_ID", "OFFERTYPE", oFFER.OFFERTYPE_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", oFFER.USER_ID)
            Return View(oFFER)
        End Function

        ' GET: OFFERs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim oFFER As OFFER = db.OFFERS.Find(id)
            If IsNothing(oFFER) Then
                Return HttpNotFound()
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", oFFER.CAR_ID)
            ViewBag.STATUS_ID = New SelectList(db.OFFER_STATUS, "STATUS_ID", "STATUS_NAME_", oFFER.STATUS_ID)
            ViewBag.OFFERTYPE_ID = New SelectList(db.OFFER_TYPE, "OFFERTYPE_ID", "OFFERTYPE", oFFER.OFFERTYPE_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", oFFER.USER_ID)
            Return View(oFFER)
        End Function

        ' POST: OFFERs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="OFFER_ID,CAR_ID,STATUS_ID,OFFERTYPE_ID,USER_ID,AMOUNT")> ByVal oFFER As OFFER) As ActionResult
            If ModelState.IsValid Then
                db.Entry(oFFER).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.CAR_ID = New SelectList(db.CARS, "CAR_ID", "CAR_REG", oFFER.CAR_ID)
            ViewBag.STATUS_ID = New SelectList(db.OFFER_STATUS, "STATUS_ID", "STATUS_NAME_", oFFER.STATUS_ID)
            ViewBag.OFFERTYPE_ID = New SelectList(db.OFFER_TYPE, "OFFERTYPE_ID", "OFFERTYPE", oFFER.OFFERTYPE_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", oFFER.USER_ID)
            Return View(oFFER)
        End Function

        ' GET: OFFERs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim oFFER As OFFER = db.OFFERS.Find(id)
            If IsNothing(oFFER) Then
                Return HttpNotFound()
            End If
            Return View(oFFER)
        End Function

        ' POST: OFFERs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim oFFER As OFFER = db.OFFERS.Find(id)
            db.OFFERS.Remove(oFFER)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
