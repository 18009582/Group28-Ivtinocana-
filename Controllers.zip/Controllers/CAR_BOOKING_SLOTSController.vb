﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class CAR_BOOKING_SLOTSController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: CAR_BOOKING_SLOTS
        Function Index() As ActionResult
            Dim cAR_BOOKING_SLOTS = db.CAR_BOOKING_SLOTS.Include(Function(c) c.BOOKING_DATES).Include(Function(c) c.BOOKING_STATUS).Include(Function(c) c.BOOKING_TIMES).Include(Function(c) c.EMPLOYEE)
            Return View(cAR_BOOKING_SLOTS.ToList())
        End Function

        ' GET: CAR_BOOKING_SLOTS/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS = db.CAR_BOOKING_SLOTS.Find(id)
            If IsNothing(cAR_BOOKING_SLOTS) Then
                Return HttpNotFound()
            End If
            Return View(cAR_BOOKING_SLOTS)
        End Function

        ' GET: CAR_BOOKING_SLOTS/Create
        Function Create() As ActionResult
            ViewBag.DAY_ = New SelectList(db.BOOKING_DATES, "DAY_", "DAY_")
            ViewBag.STATUSID = New SelectList(db.BOOKING_STATUS, "STATUSID", "STATUSNAME")
            ViewBag.TIME_ID = New SelectList(db.BOOKING_TIMES, "TIME_ID", "TIME_ID")
            ViewBag.EMPLYEE_ID = New SelectList(db.EMPLOYEEs, "EMPLYEE_ID", "FULL_NAME")
            Return View()
        End Function

        ' POST: CAR_BOOKING_SLOTS/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="TIME_ID,DAY_,STATUSID,EMPLYEE_ID,CARBOOKINGSLOTID")> ByVal cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS) As ActionResult
            If ModelState.IsValid Then
                db.CAR_BOOKING_SLOTS.Add(cAR_BOOKING_SLOTS)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.DAY_ = New SelectList(db.BOOKING_DATES, "DAY_", "DAY_", cAR_BOOKING_SLOTS.DAY_)
            ViewBag.STATUSID = New SelectList(db.BOOKING_STATUS, "STATUSID", "STATUSNAME", cAR_BOOKING_SLOTS.STATUSID)
            ViewBag.TIME_ID = New SelectList(db.BOOKING_TIMES, "TIME_ID", "TIME_ID", cAR_BOOKING_SLOTS.TIME_ID)
            ViewBag.EMPLYEE_ID = New SelectList(db.EMPLOYEEs, "EMPLYEE_ID", "FULL_NAME", cAR_BOOKING_SLOTS.EMPLYEE_ID)
            Return View(cAR_BOOKING_SLOTS)
        End Function

        ' GET: CAR_BOOKING_SLOTS/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS = db.CAR_BOOKING_SLOTS.Find(id)
            If IsNothing(cAR_BOOKING_SLOTS) Then
                Return HttpNotFound()
            End If
            ViewBag.DAY_ = New SelectList(db.BOOKING_DATES, "DAY_", "DAY_", cAR_BOOKING_SLOTS.DAY_)
            ViewBag.STATUSID = New SelectList(db.BOOKING_STATUS, "STATUSID", "STATUSNAME", cAR_BOOKING_SLOTS.STATUSID)
            ViewBag.TIME_ID = New SelectList(db.BOOKING_TIMES, "TIME_ID", "TIME_ID", cAR_BOOKING_SLOTS.TIME_ID)
            ViewBag.EMPLYEE_ID = New SelectList(db.EMPLOYEEs, "EMPLYEE_ID", "FULL_NAME", cAR_BOOKING_SLOTS.EMPLYEE_ID)
            Return View(cAR_BOOKING_SLOTS)
        End Function

        ' POST: CAR_BOOKING_SLOTS/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="TIME_ID,DAY_,STATUSID,EMPLYEE_ID,CARBOOKINGSLOTID")> ByVal cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS) As ActionResult
            If ModelState.IsValid Then
                db.Entry(cAR_BOOKING_SLOTS).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.DAY_ = New SelectList(db.BOOKING_DATES, "DAY_", "DAY_", cAR_BOOKING_SLOTS.DAY_)
            ViewBag.STATUSID = New SelectList(db.BOOKING_STATUS, "STATUSID", "STATUSNAME", cAR_BOOKING_SLOTS.STATUSID)
            ViewBag.TIME_ID = New SelectList(db.BOOKING_TIMES, "TIME_ID", "TIME_ID", cAR_BOOKING_SLOTS.TIME_ID)
            ViewBag.EMPLYEE_ID = New SelectList(db.EMPLOYEEs, "EMPLYEE_ID", "FULL_NAME", cAR_BOOKING_SLOTS.EMPLYEE_ID)
            Return View(cAR_BOOKING_SLOTS)
        End Function

        ' GET: CAR_BOOKING_SLOTS/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS = db.CAR_BOOKING_SLOTS.Find(id)
            If IsNothing(cAR_BOOKING_SLOTS) Then
                Return HttpNotFound()
            End If
            Return View(cAR_BOOKING_SLOTS)
        End Function

        ' POST: CAR_BOOKING_SLOTS/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim cAR_BOOKING_SLOTS As CAR_BOOKING_SLOTS = db.CAR_BOOKING_SLOTS.Find(id)
            db.CAR_BOOKING_SLOTS.Remove(cAR_BOOKING_SLOTS)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
