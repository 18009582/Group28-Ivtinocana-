﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Data.Entity.Validation
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class CARsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: CARs
        Function Index() As ActionResult
            Dim cARS = db.CARS.Include(Function(c) c.CAR_STATUS).Include(Function(c) c.CAR_TYPE).Include(Function(c) c.MODEL).Include(Function(c) c.USER).Include(Function(c) c.COLOUR).Include(Function(c) c.FUEL_TYPE).Include(Function(c) c.NUMBER_OF_DOORS).Include(Function(c) c.NUMBER_OF_SEATS).Include(Function(c) c.TRANSMISSION)
            Return View(cARS.ToList())
        End Function

        ' GET: CARs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR As CAR = db.CARS.Find(id)
            If IsNothing(cAR) Then
                Return HttpNotFound()
            End If
            Return View(cAR)
        End Function

        ' GET: CARs/Create
        Function Create() As ActionResult
            ViewBag.STATUS_ID = New SelectList(db.CAR_STATUS, "STATUS_ID", "SASTUS_NAME")
            ViewBag.CAR_TYPEID = New SelectList(db.CAR_TYPE, "CAR_TYPEID", "TYPE_NAME")
            ViewBag.MODEL_ID = New SelectList(db.MODELs, "MODEL_ID", "MODEL_NAME")
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME")
            ViewBag.COLOUR_ID = New SelectList(db.COLOURs, "COLOUR_ID", "COLOUR_NAME")
            ViewBag.FUELTYPE_ID = New SelectList(db.FUEL_TYPE, "FUELTYPE_ID", "FUELTYPE_NAME")
            ViewBag.DOORS_ID = New SelectList(db.NUMBER_OF_DOORS, "DOORS_ID", "DOORS_ID")
            ViewBag.SEATS_ID = New SelectList(db.NUMBER_OF_SEATS, "SEATS_ID", "SEATS_ID")
            ViewBag.TRANSMISSION_ID = New SelectList(db.TRANSMISSIONs, "TRANSMISSION_ID", "TRANSMISSION_NAME")
            Return View()
        End Function

        ' POST: CARs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="CAR_REG,SEATS_ID,COLOUR_ID,TRANSMISSION_ID,DOORS_ID,STATUS_ID,FUELTYPE_ID,MODEL_ID,YEAR,MILAGE_,LISTING_PRICE,IMAGE,CAR_ID,CAR_TYPEID,USER_ID")> ByVal cAR As CAR) As ActionResult
            If ModelState.IsValid Then
                Try
                    db.CARS.Add(cAR)
                    db.SaveChanges()
                    Return RedirectToAction("Index")
                Catch ex As DbEntityValidationException




                End Try

            End If
            ViewBag.STATUS_ID = New SelectList(db.CAR_STATUS, "STATUS_ID", "SASTUS_NAME", cAR.STATUS_ID)
            ViewBag.CAR_TYPEID = New SelectList(db.CAR_TYPE, "CAR_TYPEID", "TYPE_NAME", cAR.CAR_TYPEID)
            ViewBag.MODEL_ID = New SelectList(db.MODELs, "MODEL_ID", "MODEL_NAME", cAR.MODEL_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR.USER_ID)
            ViewBag.COLOUR_ID = New SelectList(db.COLOURs, "COLOUR_ID", "COLOUR_NAME", cAR.COLOUR_ID)
            ViewBag.FUELTYPE_ID = New SelectList(db.FUEL_TYPE, "FUELTYPE_ID", "FUELTYPE_NAME", cAR.FUELTYPE_ID)
            ViewBag.DOORS_ID = New SelectList(db.NUMBER_OF_DOORS, "DOORS_ID", "DOORS_ID", cAR.DOORS_ID)
            ViewBag.SEATS_ID = New SelectList(db.NUMBER_OF_SEATS, "SEATS_ID", "SEATS_ID", cAR.SEATS_ID)
            ViewBag.TRANSMISSION_ID = New SelectList(db.TRANSMISSIONs, "TRANSMISSION_ID", "TRANSMISSION_NAME", cAR.TRANSMISSION_ID)
            Return View(cAR)
        End Function

        ' GET: CARs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR As CAR = db.CARS.Find(id)
            If IsNothing(cAR) Then
                Return HttpNotFound()
            End If
            ViewBag.STATUS_ID = New SelectList(db.CAR_STATUS, "STATUS_ID", "SASTUS_NAME", cAR.STATUS_ID)
            ViewBag.CAR_TYPEID = New SelectList(db.CAR_TYPE, "CAR_TYPEID", "TYPE_NAME", cAR.CAR_TYPEID)
            ViewBag.MODEL_ID = New SelectList(db.MODELs, "MODEL_ID", "MODEL_NAME", cAR.MODEL_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR.USER_ID)
            ViewBag.COLOUR_ID = New SelectList(db.COLOURs, "COLOUR_ID", "COLOUR_NAME", cAR.COLOUR_ID)
            ViewBag.FUELTYPE_ID = New SelectList(db.FUEL_TYPE, "FUELTYPE_ID", "FUELTYPE_NAME", cAR.FUELTYPE_ID)
            ViewBag.DOORS_ID = New SelectList(db.NUMBER_OF_DOORS, "DOORS_ID", "DOORS_ID", cAR.DOORS_ID)
            ViewBag.SEATS_ID = New SelectList(db.NUMBER_OF_SEATS, "SEATS_ID", "SEATS_ID", cAR.SEATS_ID)
            ViewBag.TRANSMISSION_ID = New SelectList(db.TRANSMISSIONs, "TRANSMISSION_ID", "TRANSMISSION_NAME", cAR.TRANSMISSION_ID)
            Return View(cAR)
        End Function

        ' POST: CARs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="CAR_REG,SEATS_ID,COLOUR_ID,TRANSMISSION_ID,DOORS_ID,STATUS_ID,FUELTYPE_ID,MODEL_ID,YEAR,MILAGE_,LISTING_PRICE,IMAGE,CAR_ID,CAR_TYPEID,USER_ID")> ByVal cAR As CAR) As ActionResult
            If ModelState.IsValid Then
                db.Entry(cAR).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.STATUS_ID = New SelectList(db.CAR_STATUS, "STATUS_ID", "SASTUS_NAME", cAR.STATUS_ID)
            ViewBag.CAR_TYPEID = New SelectList(db.CAR_TYPE, "CAR_TYPEID", "TYPE_NAME", cAR.CAR_TYPEID)
            ViewBag.MODEL_ID = New SelectList(db.MODELs, "MODEL_ID", "MODEL_NAME", cAR.MODEL_ID)
            ViewBag.USER_ID = New SelectList(db.USERs, "USER_ID", "FIRSTNAME", cAR.USER_ID)
            ViewBag.COLOUR_ID = New SelectList(db.COLOURs, "COLOUR_ID", "COLOUR_NAME", cAR.COLOUR_ID)
            ViewBag.FUELTYPE_ID = New SelectList(db.FUEL_TYPE, "FUELTYPE_ID", "FUELTYPE_NAME", cAR.FUELTYPE_ID)
            ViewBag.DOORS_ID = New SelectList(db.NUMBER_OF_DOORS, "DOORS_ID", "DOORS_ID", cAR.DOORS_ID)
            ViewBag.SEATS_ID = New SelectList(db.NUMBER_OF_SEATS, "SEATS_ID", "SEATS_ID", cAR.SEATS_ID)
            ViewBag.TRANSMISSION_ID = New SelectList(db.TRANSMISSIONs, "TRANSMISSION_ID", "TRANSMISSION_NAME", cAR.TRANSMISSION_ID)
            Return View(cAR)
        End Function

        ' GET: CARs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR As CAR = db.CARS.Find(id)
            If IsNothing(cAR) Then
                Return HttpNotFound()
            End If
            Return View(cAR)
        End Function

        ' POST: CARs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim cAR As CAR = db.CARS.Find(id)
            db.CARS.Remove(cAR)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
