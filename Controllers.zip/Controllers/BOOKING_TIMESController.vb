﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class BOOKING_TIMESController
        Inherits System.Web.Mvc.Controller


        Private db As New VehlutionFinalEntities


        ' GET: BOOKING_TIMES
        Function Index() As ActionResult
            Return View(db.BOOKING_TIMES.ToList())
        End Function

        ' GET: BOOKING_TIMES/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_TIMES As BOOKING_TIMES = db.BOOKING_TIMES.Find(id)
            If IsNothing(bOOKING_TIMES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_TIMES)
        End Function

        ' GET: BOOKING_TIMES/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: BOOKING_TIMES/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="TIME_ID,START_TIME_,END_TIME")> ByVal bOOKING_TIMES As BOOKING_TIMES) As ActionResult
            If ModelState.IsValid Then
                db.BOOKING_TIMES.Add(bOOKING_TIMES)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(bOOKING_TIMES)
        End Function

        ' GET: BOOKING_TIMES/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_TIMES As BOOKING_TIMES = db.BOOKING_TIMES.Find(id)
            If IsNothing(bOOKING_TIMES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_TIMES)
        End Function

        ' POST: BOOKING_TIMES/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="TIME_ID,START_TIME_,END_TIME")> ByVal bOOKING_TIMES As BOOKING_TIMES) As ActionResult
            If ModelState.IsValid Then
                db.Entry(bOOKING_TIMES).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(bOOKING_TIMES)
        End Function

        ' GET: BOOKING_TIMES/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_TIMES As BOOKING_TIMES = db.BOOKING_TIMES.Find(id)
            If IsNothing(bOOKING_TIMES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_TIMES)
        End Function

        ' POST: BOOKING_TIMES/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim bOOKING_TIMES As BOOKING_TIMES = db.BOOKING_TIMES.Find(id)
            db.BOOKING_TIMES.Remove(bOOKING_TIMES)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
