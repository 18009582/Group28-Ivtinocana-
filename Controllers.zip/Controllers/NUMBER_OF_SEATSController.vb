﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class NUMBER_OF_SEATSController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: NUMBER_OF_SEATS
        Function Index() As ActionResult
            Return View(db.NUMBER_OF_SEATS.ToList())
        End Function

        ' GET: NUMBER_OF_SEATS/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim nUMBER_OF_SEATS As NUMBER_OF_SEATS = db.NUMBER_OF_SEATS.Find(id)
            If IsNothing(nUMBER_OF_SEATS) Then
                Return HttpNotFound()
            End If
            Return View(nUMBER_OF_SEATS)
        End Function

        ' GET: NUMBER_OF_SEATS/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: NUMBER_OF_SEATS/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="SEATS_ID,NUMBER_OF_SEATS_")> ByVal nUMBER_OF_SEATS As NUMBER_OF_SEATS) As ActionResult
            If ModelState.IsValid Then
                db.NUMBER_OF_SEATS.Add(nUMBER_OF_SEATS)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(nUMBER_OF_SEATS)
        End Function

        ' GET: NUMBER_OF_SEATS/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim nUMBER_OF_SEATS As NUMBER_OF_SEATS = db.NUMBER_OF_SEATS.Find(id)
            If IsNothing(nUMBER_OF_SEATS) Then
                Return HttpNotFound()
            End If
            Return View(nUMBER_OF_SEATS)
        End Function

        ' POST: NUMBER_OF_SEATS/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="SEATS_ID,NUMBER_OF_SEATS_")> ByVal nUMBER_OF_SEATS As NUMBER_OF_SEATS) As ActionResult
            If ModelState.IsValid Then
                db.Entry(nUMBER_OF_SEATS).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(nUMBER_OF_SEATS)
        End Function

        ' GET: NUMBER_OF_SEATS/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim nUMBER_OF_SEATS As NUMBER_OF_SEATS = db.NUMBER_OF_SEATS.Find(id)
            If IsNothing(nUMBER_OF_SEATS) Then
                Return HttpNotFound()
            End If
            Return View(nUMBER_OF_SEATS)
        End Function

        ' POST: NUMBER_OF_SEATS/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim nUMBER_OF_SEATS As NUMBER_OF_SEATS = db.NUMBER_OF_SEATS.Find(id)
            db.NUMBER_OF_SEATS.Remove(nUMBER_OF_SEATS)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
