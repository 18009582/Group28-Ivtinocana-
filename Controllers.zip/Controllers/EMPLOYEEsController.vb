﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Data.Entity.Validation
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class EMPLOYEEsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: EMPLOYEEs
        Function Index() As ActionResult
            Return View(db.EMPLOYEEs.ToList())
        End Function

        ' GET: EMPLOYEEs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim eMPLOYEE As EMPLOYEE = db.EMPLOYEEs.Find(id)
            If IsNothing(eMPLOYEE) Then
                Return HttpNotFound()
            End If
            Return View(eMPLOYEE)
        End Function

        ' GET: EMPLOYEEs/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: EMPLOYEEs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="EMPLYEE_ID,FULL_NAME,CELL_NUMBER,EMAIL,JOB_DESCRIPTION,DATE_HIRED")> ByVal eMPLOYEE As EMPLOYEE) As ActionResult

            If ModelState.IsValid Then
                db.EMPLOYEEs.Add(eMPLOYEE)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(eMPLOYEE)
        End Function

        ' GET: EMPLOYEEs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim eMPLOYEE As EMPLOYEE = db.EMPLOYEEs.Find(id)
            If IsNothing(eMPLOYEE) Then
                Return HttpNotFound()
            End If
            Return View(eMPLOYEE)
        End Function

        ' POST: EMPLOYEEs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="EMPLYEE_ID,FULL_NAME,CELL_NUMBER,EMAIL,JOB_DESCRIPTION,DATE_HIRED")> ByVal eMPLOYEE As EMPLOYEE) As ActionResult
            If ModelState.IsValid Then
                db.Entry(eMPLOYEE).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(eMPLOYEE)
        End Function

        ' GET: EMPLOYEEs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim eMPLOYEE As EMPLOYEE = db.EMPLOYEEs.Find(id)
            If IsNothing(eMPLOYEE) Then
                Return HttpNotFound()
            End If
            Return View(eMPLOYEE)
        End Function

        ' POST: EMPLOYEEs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim eMPLOYEE As EMPLOYEE = db.EMPLOYEEs.Find(id)
            db.EMPLOYEEs.Remove(eMPLOYEE)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
