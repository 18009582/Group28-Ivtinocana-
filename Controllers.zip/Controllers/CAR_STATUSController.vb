﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class CAR_STATUSController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: CAR_STATUS
        Function Index() As ActionResult
            Return View(db.CAR_STATUS.ToList())
        End Function

        ' GET: CAR_STATUS/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_STATUS As CAR_STATUS = db.CAR_STATUS.Find(id)
            If IsNothing(cAR_STATUS) Then
                Return HttpNotFound()
            End If
            Return View(cAR_STATUS)
        End Function

        ' GET: CAR_STATUS/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: CAR_STATUS/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="STATUS_ID,SASTUS_NAME")> ByVal cAR_STATUS As CAR_STATUS) As ActionResult
            If ModelState.IsValid Then
                db.CAR_STATUS.Add(cAR_STATUS)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(cAR_STATUS)
        End Function

        ' GET: CAR_STATUS/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_STATUS As CAR_STATUS = db.CAR_STATUS.Find(id)
            If IsNothing(cAR_STATUS) Then
                Return HttpNotFound()
            End If
            Return View(cAR_STATUS)
        End Function

        ' POST: CAR_STATUS/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="STATUS_ID,SASTUS_NAME")> ByVal cAR_STATUS As CAR_STATUS) As ActionResult
            If ModelState.IsValid Then
                db.Entry(cAR_STATUS).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(cAR_STATUS)
        End Function

        ' GET: CAR_STATUS/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim cAR_STATUS As CAR_STATUS = db.CAR_STATUS.Find(id)
            If IsNothing(cAR_STATUS) Then
                Return HttpNotFound()
            End If
            Return View(cAR_STATUS)
        End Function

        ' POST: CAR_STATUS/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim cAR_STATUS As CAR_STATUS = db.CAR_STATUS.Find(id)
            db.CAR_STATUS.Remove(cAR_STATUS)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
