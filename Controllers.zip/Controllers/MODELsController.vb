﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class MODELsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: MODELs
        Function Index() As ActionResult
            Dim mODELs = db.MODELs.Include(Function(m) m.MAKE)
            Return View(mODELs.ToList())
        End Function

        ' GET: MODELs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mODEL As MODEL = db.MODELs.Find(id)
            If IsNothing(mODEL) Then
                Return HttpNotFound()
            End If
            Return View(mODEL)
        End Function

        ' GET: MODELs/Create
        Function Create() As ActionResult
            ViewBag.MAKE_ID = New SelectList(db.MAKEs, "MAKE_ID", "MAKE_NAME")
            Return View()
        End Function

        ' POST: MODELs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="MODEL_ID,MAKE_ID,MODEL_NAME")> ByVal mODEL As MODEL) As ActionResult
            If ModelState.IsValid Then
                db.MODELs.Add(mODEL)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.MAKE_ID = New SelectList(db.MAKEs, "MAKE_ID", "MAKE_NAME", mODEL.MAKE_ID)
            Return View(mODEL)
        End Function

        ' GET: MODELs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mODEL As MODEL = db.MODELs.Find(id)
            If IsNothing(mODEL) Then
                Return HttpNotFound()
            End If
            ViewBag.MAKE_ID = New SelectList(db.MAKEs, "MAKE_ID", "MAKE_NAME", mODEL.MAKE_ID)
            Return View(mODEL)
        End Function

        ' POST: MODELs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="MODEL_ID,MAKE_ID,MODEL_NAME")> ByVal mODEL As MODEL) As ActionResult
            If ModelState.IsValid Then
                db.Entry(mODEL).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            ViewBag.MAKE_ID = New SelectList(db.MAKEs, "MAKE_ID", "MAKE_NAME", mODEL.MAKE_ID)
            Return View(mODEL)
        End Function

        ' GET: MODELs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim mODEL As MODEL = db.MODELs.Find(id)
            If IsNothing(mODEL) Then
                Return HttpNotFound()
            End If
            Return View(mODEL)
        End Function

        ' POST: MODELs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim mODEL As MODEL = db.MODELs.Find(id)
            db.MODELs.Remove(mODEL)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
