﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class TRANSMISSIONsController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: TRANSMISSIONs
        Function Index() As ActionResult
            Return View(db.TRANSMISSIONs.ToList())
        End Function

        ' GET: TRANSMISSIONs/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim tRANSMISSION As TRANSMISSION = db.TRANSMISSIONs.Find(id)
            If IsNothing(tRANSMISSION) Then
                Return HttpNotFound()
            End If
            Return View(tRANSMISSION)
        End Function

        ' GET: TRANSMISSIONs/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: TRANSMISSIONs/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="TRANSMISSION_ID,TRANSMISSION_NAME")> ByVal tRANSMISSION As TRANSMISSION) As ActionResult
            If ModelState.IsValid Then
                db.TRANSMISSIONs.Add(tRANSMISSION)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(tRANSMISSION)
        End Function

        ' GET: TRANSMISSIONs/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim tRANSMISSION As TRANSMISSION = db.TRANSMISSIONs.Find(id)
            If IsNothing(tRANSMISSION) Then
                Return HttpNotFound()
            End If
            Return View(tRANSMISSION)
        End Function

        ' POST: TRANSMISSIONs/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="TRANSMISSION_ID,TRANSMISSION_NAME")> ByVal tRANSMISSION As TRANSMISSION) As ActionResult
            If ModelState.IsValid Then
                db.Entry(tRANSMISSION).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(tRANSMISSION)
        End Function

        ' GET: TRANSMISSIONs/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim tRANSMISSION As TRANSMISSION = db.TRANSMISSIONs.Find(id)
            If IsNothing(tRANSMISSION) Then
                Return HttpNotFound()
            End If
            Return View(tRANSMISSION)
        End Function

        ' POST: TRANSMISSIONs/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim tRANSMISSION As TRANSMISSION = db.TRANSMISSIONs.Find(id)
            db.TRANSMISSIONs.Remove(tRANSMISSION)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
