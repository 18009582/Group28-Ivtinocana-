﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Data.Entity
Imports System.Linq
Imports System.Net
Imports System.Web
Imports System.Web.Mvc
Imports Vehlution1._0

Namespace Controllers
    Public Class BOOKING_DATESController
        Inherits System.Web.Mvc.Controller

        Private db As New VehlutionFinalEntities

        ' GET: BOOKING_DATES
        Function Index() As ActionResult
            Return View(db.BOOKING_DATES.ToList())
        End Function

        ' GET: BOOKING_DATES/Details/5
        Function Details(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_DATES As BOOKING_DATES = db.BOOKING_DATES.Find(id)
            If IsNothing(bOOKING_DATES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_DATES)
        End Function

        ' GET: BOOKING_DATES/Create
        Function Create() As ActionResult
            Return View()
        End Function

        ' POST: BOOKING_DATES/Create
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Create(<Bind(Include:="DAY_,DATE")> ByVal bOOKING_DATES As BOOKING_DATES) As ActionResult
            If ModelState.IsValid Then
                db.BOOKING_DATES.Add(bOOKING_DATES)
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(bOOKING_DATES)
        End Function

        ' GET: BOOKING_DATES/Edit/5
        Function Edit(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_DATES As BOOKING_DATES = db.BOOKING_DATES.Find(id)
            If IsNothing(bOOKING_DATES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_DATES)
        End Function

        ' POST: BOOKING_DATES/Edit/5
        'To protect from overposting attacks, enable the specific properties you want to bind to, for 
        'more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        <HttpPost()>
        <ValidateAntiForgeryToken()>
        Function Edit(<Bind(Include:="DAY_,DATE")> ByVal bOOKING_DATES As BOOKING_DATES) As ActionResult
            If ModelState.IsValid Then
                db.Entry(bOOKING_DATES).State = EntityState.Modified
                db.SaveChanges()
                Return RedirectToAction("Index")
            End If
            Return View(bOOKING_DATES)
        End Function

        ' GET: BOOKING_DATES/Delete/5
        Function Delete(ByVal id As Integer?) As ActionResult
            If IsNothing(id) Then
                Return New HttpStatusCodeResult(HttpStatusCode.BadRequest)
            End If
            Dim bOOKING_DATES As BOOKING_DATES = db.BOOKING_DATES.Find(id)
            If IsNothing(bOOKING_DATES) Then
                Return HttpNotFound()
            End If
            Return View(bOOKING_DATES)
        End Function

        ' POST: BOOKING_DATES/Delete/5
        <HttpPost()>
        <ActionName("Delete")>
        <ValidateAntiForgeryToken()>
        Function DeleteConfirmed(ByVal id As Integer) As ActionResult
            Dim bOOKING_DATES As BOOKING_DATES = db.BOOKING_DATES.Find(id)
            db.BOOKING_DATES.Remove(bOOKING_DATES)
            db.SaveChanges()
            Return RedirectToAction("Index")
        End Function

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If (disposing) Then
                db.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
    End Class
End Namespace
